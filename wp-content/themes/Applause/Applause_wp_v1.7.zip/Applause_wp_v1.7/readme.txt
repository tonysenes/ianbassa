Theme Name: Ideanoss Theme
Theme URI: 
Author: MetroThemes
Author URI:  http://metrothemes.me
Description: Ideanosse Responsive One Page WP Theme. Author page Themeforest <a href="http://themeforest.net/user/metrothemes/profile?ref=metrothemes">Metrothemes</a>.
Version: 1.0
License: GNU General Public License
License URI: license.txt
Tags: light, white,minimal,onepage, editor-style, featured-images, theme-options